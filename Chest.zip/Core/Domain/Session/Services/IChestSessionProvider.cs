namespace Core.Domain.Session.Services
{
    public interface IChestSessionProvider
    {
        ChestSession GetSession() ;
    }
}